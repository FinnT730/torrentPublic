package processing.test.cookie;

import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Cookie extends PApplet {

drawCookie cookie;


public void setup() {
 
 orientation(LANDSCAPE);
 background(color(10,240,5));
 cookie.init();
}

public void draw() {
  fill(255);
  float area = map(0,displayWidth,10,20,1);
  rect(area,area+10,area,area);
}

public void mousePressed() {
  if(true) {
    fill(255);
    rect(10,10,30,30);
  } else {
    fill(20,60,40);
    rect(10,10,30,30);
  }
}
class drawCookie {
 
  
  int x, y = 0;
  
  int timer = 0;
  boolean enable = true;
  
  public void init() {
    while(enable && timer != 20) {
      timer++;
      update();
    }
    enable = false;
  }
  
  public void update() {
    for(int i = 0; i < displayWidth; i += 10) {
        for(int j = 0; j < displayHeight; j += 10) {
            fill((i + j) % 255,timer,20);
            rect(i,j,10,10);
        }
    }
  }

  
  
}
  public void settings() {  size(displayWidth, displayHeight); }
}
